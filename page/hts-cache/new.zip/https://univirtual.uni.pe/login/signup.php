<!DOCTYPE html>

<html  dir="ltr" lang="es" xml:lang="es">
<head>
    <title>Nueva cuenta</title>
    <link rel="shortcut icon" href="https://univirtual.uni.pe/pluginfile.php/1/theme_moove/favicon/1711504030/eecc%20.ico" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, Nueva cuenta" />
<link rel="stylesheet" type="text/css" href="https://univirtual.uni.pe/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.css" /><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="https://univirtual.uni.pe/theme/styles.php/moove/1711504030_1690982899/all" />
<script>
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"https:\/\/univirtual.uni.pe","homeurl":{},"sesskey":"WSoRmvSSYf","sessiontimeout":"14400","sessiontimeoutwarning":1200,"themerev":"1711504030","slasharguments":1,"theme":"moove","iconsystemmodule":"core\/icon_system_fontawesome","jsrev":"1711504034","admin":"admin","svgicons":true,"usertimezone":"Am\u00e9rica\/Lima","courseId":1,"courseContextId":2,"contextid":1,"contextInstanceId":0,"langrev":1720603291,"templaterev":"1711504034"};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''}
if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else{me.path=component+'/'+component+'.'+me.type}};
YUI_config = {"debug":false,"base":"https:\/\/univirtual.uni.pe\/lib\/yuilib\/3.17.2\/","comboBase":"https:\/\/univirtual.uni.pe\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"https:\/\/univirtual.uni.pe\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"https:\/\/univirtual.uni.pe\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"https:\/\/univirtual.uni.pe\/theme\/yui_combo.php?m\/1711504034\/","combine":true,"comboBase":"https:\/\/univirtual.uni.pe\/theme\/yui_combo.php?","ext":false,"root":"m\/1711504034\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core-handlebars":{"condition":{"trigger":"handlebars","when":"after"}},"moodle-core-event":{"requires":["event-custom"]},"moodle-core-languninstallconfirm":{"requires":["base","node","moodle-core-notification-confirm","moodle-core-notification-alert"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-core-maintenancemodetimer":{"requires":["base","node"]},"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-popuphelp":{"requires":["moodle-core-tooltip"]},"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-dragdrop":{"requires":["base","node","io","dom","dd","event-key","event-focus","moodle-core-notification"]},"moodle-core-tooltip":{"requires":["base","node","io-base","moodle-core-notification-dialogue","json-parse","widget-position","widget-position-align","event-outside","cache-base"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","escape","event-key","dd-plugin","moodle-core-widget-focusafterclose","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-formchangechecker":{"requires":["base","event-focus","moodle-core-event"]},"moodle-core_availability-form":{"requires":["base","node","event","event-delegate","panel","moodle-core-notification-dialogue","json"]},"moodle-backup-confirmcancel":{"requires":["node","node-event-simulate","moodle-core-notification-confirm"]},"moodle-backup-backupselectall":{"requires":["node","event","node-event-simulate","anim"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-course-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-course-coursebase","moodle-course-util"]},"moodle-form-passwordunmask":{"requires":[]},"moodle-form-shortforms":{"requires":["node","base","selector-css3","moodle-core-event"]},"moodle-form-dateselector":{"requires":["base","node","overlay","calendar"]},"moodle-question-preview":{"requires":["base","dom","event-delegate","event-key","core_question_engine"]},"moodle-question-searchform":{"requires":["base","node"]},"moodle-question-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-availability_completion-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_date-form":{"requires":["base","node","event","io","moodle-core_availability-form"]},"moodle-availability_grade-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_group-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_grouping-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_profile-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-mod_assign-history":{"requires":["node","transition"]},"moodle-mod_attendance-groupfilter":{"requires":["base","node"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form"]},"moodle-mod_quiz-modform":{"requires":["base","node","event"]},"moodle-mod_quiz-quizbase":{"requires":["base","node"]},"moodle-mod_quiz-util":{"requires":["node","moodle-core-actionmenu"],"use":["moodle-mod_quiz-util-base"],"submodules":{"moodle-mod_quiz-util-base":{},"moodle-mod_quiz-util-slot":{"requires":["node","moodle-mod_quiz-util-base"]},"moodle-mod_quiz-util-page":{"requires":["node","moodle-mod_quiz-util-base"]}}},"moodle-mod_quiz-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-base","moodle-mod_quiz-util-page","moodle-mod_quiz-util-slot","moodle-course-util"]},"moodle-mod_quiz-questionchooser":{"requires":["moodle-core-chooserdialogue","moodle-mod_quiz-util","querystring-parse"]},"moodle-mod_quiz-toolboxes":{"requires":["base","node","event","event-key","io","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-slot","moodle-core-notification-ajaxexception"]},"moodle-message_airnotifier-toolboxes":{"requires":["base","node","io"]},"moodle-filter_glossary-autolinker":{"requires":["base","node","io-base","json-parse","event-delegate","overlay","moodle-core-event","moodle-core-notification-alert","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-filter_mathjaxloader-loader":{"requires":["moodle-core-event"]},"moodle-editor_atto-rangy":{"requires":[]},"moodle-editor_atto-editor":{"requires":["node","transition","io","overlay","escape","event","event-simulate","event-custom","node-event-html5","node-event-simulate","yui-throttle","moodle-core-notification-dialogue","moodle-core-notification-confirm","moodle-editor_atto-rangy","handlebars","timers","querystring-stringify"]},"moodle-editor_atto-plugin":{"requires":["node","base","escape","event","event-outside","handlebars","event-custom","timers","moodle-editor_atto-menu"]},"moodle-editor_atto-menu":{"requires":["moodle-core-notification-dialogue","node","event","event-custom"]},"moodle-report_eventlist-eventfilter":{"requires":["base","event","node","node-event-delegate","datatable","autocomplete","autocomplete-filters"]},"moodle-report_loglive-fetchlogs":{"requires":["base","event","node","io","node-event-delegate"]},"moodle-gradereport_history-userselector":{"requires":["escape","event-delegate","event-key","handlebars","io-base","json-parse","moodle-core-notification-dialogue"]},"moodle-qbank_editquestion-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-tool_capability-search":{"requires":["base","node"]},"moodle-tool_lp-dragdrop-reorder":{"requires":["moodle-core-dragdrop"]},"moodle-tool_monitor-dropdown":{"requires":["base","event","node"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","event-resize","transition","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-alert","moodle-core-notification-warning","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-atto_accessibilitychecker-button":{"requires":["color-base","moodle-editor_atto-plugin"]},"moodle-atto_accessibilityhelper-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_align-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_bold-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_charmap-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_clear-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_collapse-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emojipicker-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emoticon-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_equation-button":{"requires":["moodle-editor_atto-plugin","moodle-core-event","io","event-valuechange","tabview","array-extras"]},"moodle-atto_h5p-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_html-button":{"requires":["promise","moodle-editor_atto-plugin","moodle-atto_html-beautify","moodle-atto_html-codemirror","event-valuechange"]},"moodle-atto_html-codemirror":{"requires":["moodle-atto_html-codemirror-skin"]},"moodle-atto_html-beautify":{},"moodle-atto_image-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_indent-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_italic-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_link-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-usedfiles":{"requires":["node","escape"]},"moodle-atto_managefiles-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_media-button":{"requires":["moodle-editor_atto-plugin","moodle-form-shortforms"]},"moodle-atto_noautolink-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_orderedlist-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_recordrtc-button":{"requires":["moodle-editor_atto-plugin","moodle-atto_recordrtc-recording"]},"moodle-atto_recordrtc-recording":{"requires":["moodle-atto_recordrtc-button"]},"moodle-atto_rtl-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_strike-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_subscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_superscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_table-button":{"requires":["moodle-editor_atto-plugin","moodle-editor_atto-menu","event","event-valuechange"]},"moodle-atto_title-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_underline-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_undo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_unorderedlist-button":{"requires":["moodle-editor_atto-plugin"]}}},"gallery":{"name":"gallery","base":"https:\/\/univirtual.uni.pe\/lib\/yuilib\/gallery\/","combine":true,"comboBase":"https:\/\/univirtual.uni.pe\/theme\/yui_combo.php?","ext":false,"root":"gallery\/1711504034\/","patterns":{"gallery-":{"group":"gallery"}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"https:\/\/univirtual.uni.pe\/lib\/javascript.php\/1711504034\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker","moodle-core-notification-dialogue"]},"core_comment":{"name":"core_comment","fullpath":"https:\/\/univirtual.uni.pe\/lib\/javascript.php\/1711504034\/comment\/comment.js","requires":["base","io-base","node","json","yui2-animation","overlay","escape"]},"mathjax":{"name":"mathjax","fullpath":"https:\/\/cdn.jsdelivr.net\/npm\/mathjax@2.7.9\/MathJax.js?delayStartupUntil=configured"}}};
M.yui.loader = {modules: {}};

//]]>
</script>

<meta name="google-site-verification" content="y5KZGjb9Zukau4rnu3OX24EnQbvUp2hy1Jxpi7iGu2s" /><meta name="robots" content="noindex" /><link rel="preconnect" href="https://fonts.googleapis.com">
                       <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                       <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,400&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body  id="page-login-signup" class="format-site  path-login dir-ltr lang-es yui-skin-sam yui3-skin-sam univirtual-uni-pe pagelayout-login course-1 context-1 notloggedin moove-login">
<div class="toast-wrapper mx-auto py-0 fixed-top" role="status" aria-live="polite"></div>

<div id="page-wrapper">

    <div>
    <a class="sr-only sr-only-focusable" href="#maincontent">Salta al contenido principal</a>
</div><script src="https://univirtual.uni.pe/lib/javascript.php/1711504034/lib/polyfills/polyfill.js"></script>
<script src="https://univirtual.uni.pe/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.js"></script><script src="https://univirtual.uni.pe/lib/javascript.php/1711504034/lib/javascript-static.js"></script>
<script>
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>



    <div id="page" class="container-fluid mt-0">
        <div id="page-content" class="row">
            <div id="region-main-box" class="col-12">
                <section id="region-main" class="col-12 h-100" aria-label="Contenido">
                    <div class="login-wrapper">
                        <div class="login-container">
                            <div role="main"><span id="maincontent"></span><div class="signupform">
    <h1 class="login-heading">Nueva cuenta</h1>
    
<form autocomplete="off" action="https://univirtual.uni.pe/login/signup.php" method="post" accept-charset="utf-8" id="mform1_vq5rEzJkbYuhrg5" class="mform full-width-labels">
	<div style="display: none;"><input name="sesskey" type="hidden" value="WSoRmvSSYf" />
<input name="_qf__login_signup_form" type="hidden" value="1" />
</div>

<div id="fitem_id_username" class="form-group row  fitem   " >
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
                <label id="id_username_label" class="d-inline word-break " for="id_username">
                    Nombre de usuario
                </label>
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
                <div class="text-danger" title="Obligatorio">
                <i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Obligatorio" role="img" aria-label="Obligatorio"></i>
                </div>
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="username"
                id="id_username"
                value=""
                size="12"
                maxlength="100" autocapitalize="none" >
        <div class="form-control-feedback invalid-feedback" id="id_error_username" >
            
        </div>
    </div>
</div><div id="fitem_id_passwordpolicyinfo" class="form-group row  fitem femptylabel  " >
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="static">
        <div class="form-control-static">
        La contraseña debería tener al menos 8 caracter(es)
        </div>
        <div class="form-control-feedback invalid-feedback" id="id_error_passwordpolicyinfo" >
            
        </div>
    </div>
</div><div id="fitem_id_password" class="form-group row  fitem   " >
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
                <label id="id_password_label" class="d-inline word-break " for="id_password">
                    Contraseña
                </label>
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
                <div class="text-danger" title="Obligatorio">
                <i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Obligatorio" role="img" aria-label="Obligatorio"></i>
                </div>
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="password">
        <input type="password"
                class="form-control "
                name="password"
                id="id_password"
                value=""
                size="12"
 maxlength="32" autocomplete="new-password">
        <div class="form-control-feedback invalid-feedback" id="id_error_password" >
            
        </div>
    </div>
</div><div id="fitem_id_email" class="form-group row  fitem   " >
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
                <label id="id_email_label" class="d-inline word-break " for="id_email">
                    Dirección de correo
                </label>
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
                <div class="text-danger" title="Obligatorio">
                <i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Obligatorio" role="img" aria-label="Obligatorio"></i>
                </div>
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="email"
                id="id_email"
                value=""
                size="25"
                maxlength="100" >
        <div class="form-control-feedback invalid-feedback" id="id_error_email" >
            
        </div>
    </div>
</div><div id="fitem_id_email2" class="form-group row  fitem   " >
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
                <label id="id_email2_label" class="d-inline word-break " for="id_email2">
                    Correo (de nuevo)
                </label>
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
                <div class="text-danger" title="Obligatorio">
                <i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Obligatorio" role="img" aria-label="Obligatorio"></i>
                </div>
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="email2"
                id="id_email2"
                value=""
                size="25"
                maxlength="100" >
        <div class="form-control-feedback invalid-feedback" id="id_error_email2" >
            
        </div>
    </div>
</div><div id="fitem_id_firstname" class="form-group row  fitem   " >
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
                <label id="id_firstname_label" class="d-inline word-break " for="id_firstname">
                    Nombre
                </label>
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
                <div class="text-danger" title="Obligatorio">
                <i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Obligatorio" role="img" aria-label="Obligatorio"></i>
                </div>
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="firstname"
                id="id_firstname"
                value=""
                size="30"
                maxlength="100" >
        <div class="form-control-feedback invalid-feedback" id="id_error_firstname" >
            
        </div>
    </div>
</div><div id="fitem_id_lastname" class="form-group row  fitem   " >
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
                <label id="id_lastname_label" class="d-inline word-break " for="id_lastname">
                    Apellido(s)
                </label>
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
                <div class="text-danger" title="Obligatorio">
                <i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Obligatorio" role="img" aria-label="Obligatorio"></i>
                </div>
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="lastname"
                id="id_lastname"
                value=""
                size="30"
                maxlength="100" >
        <div class="form-control-feedback invalid-feedback" id="id_error_lastname" >
            
        </div>
    </div>
</div><div id="fitem_id_city" class="form-group row  fitem   " >
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
                <label id="id_city_label" class="d-inline word-break " for="id_city">
                    Ciudad
                </label>
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="city"
                id="id_city"
                value="Lima"
                size="20"
                maxlength="120" >
        <div class="form-control-feedback invalid-feedback" id="id_error_city" >
            
        </div>
    </div>
</div><div id="fitem_id_country" class="form-group row  fitem   " >
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
                <label id="id_country_label" class="d-inline word-break " for="id_country">
                    País
                </label>
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="country"
            id="id_country"
            
            
             >
            <option value=""  
                >Seleccione su país</option>
            <option value="AF"  
                >Afganistán</option>
            <option value="AL"  
                >Albania</option>
            <option value="DE"  
                >Alemania</option>
            <option value="AD"  
                >Andorra</option>
            <option value="AO"  
                >Angola</option>
            <option value="AI"  
                >Anguila</option>
            <option value="AQ"  
                >Antártida</option>
            <option value="AG"  
                >Antigua y Barbuda</option>
            <option value="SA"  
                >Arabia Saudita</option>
            <option value="DZ"  
                >Argelia</option>
            <option value="AR"  
                >Argentina</option>
            <option value="AM"  
                >Armenia</option>
            <option value="AW"  
                >Aruba</option>
            <option value="AU"  
                >Australia</option>
            <option value="AT"  
                >Austria</option>
            <option value="AZ"  
                >Azerbaiyán</option>
            <option value="BS"  
                >Bahamas</option>
            <option value="BH"  
                >Bahrein</option>
            <option value="BD"  
                >Bangladesh</option>
            <option value="BB"  
                >Barbados</option>
            <option value="BE"  
                >Bélgica</option>
            <option value="BZ"  
                >Belice</option>
            <option value="BJ"  
                >Benin</option>
            <option value="BM"  
                >Bermuda</option>
            <option value="BY"  
                >Bielorrusia</option>
            <option value="BO"  
                >Bolivia (Estado Plurinacional de)</option>
            <option value="BQ"  
                >Bonaire, San Eustaquio y Saba</option>
            <option value="BA"  
                >Bosnia y Herzegovina</option>
            <option value="BW"  
                >Botswana</option>
            <option value="BR"  
                >Brasil</option>
            <option value="BN"  
                >Brunei Darussalam</option>
            <option value="BG"  
                >Bulgaria</option>
            <option value="BF"  
                >Burkina Faso</option>
            <option value="BI"  
                >Burundi</option>
            <option value="BT"  
                >Bután</option>
            <option value="CV"  
                >Cabo Verde</option>
            <option value="KH"  
                >Camboya</option>
            <option value="CM"  
                >Camerún</option>
            <option value="CA"  
                >Canadá</option>
            <option value="TD"  
                >Chad</option>
            <option value="CL"  
                >Chile</option>
            <option value="CN"  
                >China</option>
            <option value="CY"  
                >Chipre</option>
            <option value="CO"  
                >Colombia</option>
            <option value="KM"  
                >Comoras</option>
            <option value="CG"  
                >Congo</option>
            <option value="CD"  
                >Congo (República Democrática del)</option>
            <option value="KR"  
                >Corea (República de)</option>
            <option value="KP"  
                >Corea (República Popular Democrática de)</option>
            <option value="CI"  
                >Costa de Marfil</option>
            <option value="CR"  
                >Costa Rica</option>
            <option value="HR"  
                >Croacia</option>
            <option value="CU"  
                >Cuba</option>
            <option value="CW"  
                >Curazao</option>
            <option value="DK"  
                >Dinamarca</option>
            <option value="DJ"  
                >Djibouti</option>
            <option value="DM"  
                >Dominica</option>
            <option value="EC"  
                >Ecuador</option>
            <option value="EG"  
                >Egipto</option>
            <option value="SV"  
                >El Salvador</option>
            <option value="VA"  
                >El Vaticano</option>
            <option value="AE"  
                >Emiratos Árabes Unidos</option>
            <option value="ER"  
                >Eritrea</option>
            <option value="SK"  
                >Eslovaquia</option>
            <option value="SI"  
                >Eslovenia</option>
            <option value="ES"  
                >España</option>
            <option value="US"  
                >Estados Unidos</option>
            <option value="EE"  
                >Estonia</option>
            <option value="ET"  
                >Etiopía</option>
            <option value="RU"  
                >Federación Rusa</option>
            <option value="FJ"  
                >Fiji</option>
            <option value="PH"  
                >Filipinas</option>
            <option value="FI"  
                >Finlandia</option>
            <option value="FR"  
                >Francia</option>
            <option value="GA"  
                >Gabón</option>
            <option value="GM"  
                >Gambia</option>
            <option value="GE"  
                >Georgia</option>
            <option value="GS"  
                >Georgia del Sur y Las Islas Sandwich del Sur</option>
            <option value="GH"  
                >Ghana</option>
            <option value="GI"  
                >Gibraltar</option>
            <option value="GD"  
                >Granada</option>
            <option value="GR"  
                >Grecia</option>
            <option value="GL"  
                >Groenlandia</option>
            <option value="GP"  
                >Guadalupe</option>
            <option value="GU"  
                >Guam</option>
            <option value="GT"  
                >Guatemala</option>
            <option value="GG"  
                >Guernsey</option>
            <option value="GN"  
                >Guinea</option>
            <option value="GQ"  
                >Guinea Ecuatorial</option>
            <option value="GW"  
                >Guinea-Bissau</option>
            <option value="GY"  
                >Guyana</option>
            <option value="GF"  
                >Guyana Francesa</option>
            <option value="HT"  
                >Haití</option>
            <option value="NL"  
                >Holanda</option>
            <option value="HN"  
                >Honduras</option>
            <option value="HK"  
                >Hong Kong</option>
            <option value="HU"  
                >Hungría</option>
            <option value="IN"  
                >India</option>
            <option value="ID"  
                >Indonesia</option>
            <option value="IQ"  
                >Irak</option>
            <option value="IR"  
                >Irán (República Islámica de)</option>
            <option value="IE"  
                >Irlanda</option>
            <option value="IM"  
                >Isla de Man</option>
            <option value="HM"  
                >Isla Heard e Islas  McDonald</option>
            <option value="IS"  
                >Islandia</option>
            <option value="AX"  
                >Islas Åland</option>
            <option value="BV"  
                >Islas Bouvet</option>
            <option value="KY"  
                >Islas Caimán</option>
            <option value="CC"  
                >Islas Cocos</option>
            <option value="CK"  
                >Islas Cook</option>
            <option value="CX"  
                >Islas de Navidad</option>
            <option value="FO"  
                >Islas Faroe</option>
            <option value="FK"  
                >Islas Malvinas</option>
            <option value="MP"  
                >Islas Marianas del Norte</option>
            <option value="MH"  
                >Islas Marshall</option>
            <option value="NF"  
                >Islas Norfolk</option>
            <option value="SB"  
                >Islas Salomón</option>
            <option value="SJ"  
                >Islas Svalbard y Jan Mayen</option>
            <option value="TC"  
                >Islas Turcas y Caicos</option>
            <option value="VI"  
                >Islas Vírgenes (Americanas)</option>
            <option value="VG"  
                >Islas Vírgenes (Británicas)</option>
            <option value="WF"  
                >Islas Wallis y Futuna</option>
            <option value="IL"  
                >Israel</option>
            <option value="IT"  
                >Italia</option>
            <option value="JM"  
                >Jamaica</option>
            <option value="JP"  
                >Japón</option>
            <option value="JE"  
                >Jersey</option>
            <option value="JO"  
                >Jordania</option>
            <option value="KZ"  
                >Kazajstán</option>
            <option value="KE"  
                >Kenia</option>
            <option value="KG"  
                >Kirguistán</option>
            <option value="KI"  
                >Kiribati</option>
            <option value="KW"  
                >Kuwait</option>
            <option value="LA"  
                >Laos</option>
            <option value="LV"  
                >Latvia</option>
            <option value="LS"  
                >Lesotho</option>
            <option value="LB"  
                >Líbano</option>
            <option value="LR"  
                >Liberia</option>
            <option value="LY"  
                >Libia</option>
            <option value="LI"  
                >Liechtenstein</option>
            <option value="LT"  
                >Lituania</option>
            <option value="LU"  
                >Luxemburgo</option>
            <option value="MO"  
                >Macao</option>
            <option value="MK"  
                >Macedonia del Norte</option>
            <option value="MG"  
                >Madagascar</option>
            <option value="MY"  
                >Malasia</option>
            <option value="MW"  
                >Malawi</option>
            <option value="MV"  
                >Maldivas</option>
            <option value="ML"  
                >Mali</option>
            <option value="MT"  
                >Malta</option>
            <option value="MA"  
                >Marruecos</option>
            <option value="MQ"  
                >Martinica</option>
            <option value="MU"  
                >Mauricio</option>
            <option value="MR"  
                >Mauritania</option>
            <option value="YT"  
                >Mayotte</option>
            <option value="MX"  
                >México</option>
            <option value="FM"  
                >Micronesia ( Estados Federados de)</option>
            <option value="MD"  
                >Moldavia (República de Moldavia)</option>
            <option value="MC"  
                >Mónaco</option>
            <option value="MN"  
                >Mongolia</option>
            <option value="ME"  
                >Montenegro</option>
            <option value="MS"  
                >Montserrat</option>
            <option value="MZ"  
                >Mozambique</option>
            <option value="MM"  
                >Myanmar</option>
            <option value="NA"  
                >Namibia</option>
            <option value="NR"  
                >Naurú</option>
            <option value="NP"  
                >Nepal</option>
            <option value="NI"  
                >Nicaragua</option>
            <option value="NE"  
                >Níger</option>
            <option value="NG"  
                >Nigeria</option>
            <option value="NU"  
                >Niue</option>
            <option value="NO"  
                >Noruega</option>
            <option value="NC"  
                >Nueva Caledonia</option>
            <option value="NZ"  
                >Nueva Zelandia</option>
            <option value="OM"  
                >Omán</option>
            <option value="PK"  
                >Pakistán</option>
            <option value="PW"  
                >Palau</option>
            <option value="PS"  
                >Palestina, Estado de</option>
            <option value="PA"  
                >Panamá</option>
            <option value="PG"  
                >Papúa Nueva Guinea</option>
            <option value="PY"  
                >Paraguay</option>
            <option value="PE" selected 
                >Perú</option>
            <option value="PN"  
                >Pitcairn</option>
            <option value="PF"  
                >Polinesia Francesa</option>
            <option value="PL"  
                >Polonia</option>
            <option value="PT"  
                >Portugal</option>
            <option value="PR"  
                >Puerto Rico</option>
            <option value="QA"  
                >Qatar</option>
            <option value="GB"  
                >Reino Unido</option>
            <option value="CF"  
                >República Centroafricana</option>
            <option value="CZ"  
                >República Checa</option>
            <option value="DO"  
                >República Dominicana</option>
            <option value="RE"  
                >Reunión</option>
            <option value="RW"  
                >Ruanda</option>
            <option value="RO"  
                >Rumania</option>
            <option value="EH"  
                >Sahara Occidental</option>
            <option value="BL"  
                >Saint Barthélemy</option>
            <option value="WS"  
                >Samoa</option>
            <option value="AS"  
                >Samoa Americana</option>
            <option value="KN"  
                >San Cristóbal y Nevis</option>
            <option value="SM"  
                >San Marino</option>
            <option value="SX"  
                >San Martín (Parte Holandesa)</option>
            <option value="MF"  
                >San Martín (zona Francesa)</option>
            <option value="PM"  
                >San Pedro y Miquelon</option>
            <option value="VC"  
                >San Vincente y Las Granadinas</option>
            <option value="SH"  
                >Santa Elena, Ascensión y Tristán de Acuña</option>
            <option value="LC"  
                >Santa Lucía</option>
            <option value="ST"  
                >Santo Tomé y Príncipe</option>
            <option value="SN"  
                >Senegal</option>
            <option value="RS"  
                >Serbia</option>
            <option value="SC"  
                >Seychelles</option>
            <option value="SL"  
                >Sierra Leona</option>
            <option value="SG"  
                >Singapur</option>
            <option value="SY"  
                >Siria</option>
            <option value="SO"  
                >Somalía</option>
            <option value="LK"  
                >Sri Lanka</option>
            <option value="ZA"  
                >Sudáfrica</option>
            <option value="SD"  
                >Sudán</option>
            <option value="SS"  
                >Sudán del Sur</option>
            <option value="SE"  
                >Suecia</option>
            <option value="CH"  
                >Suiza</option>
            <option value="SR"  
                >Surinam</option>
            <option value="SZ"  
                >Swazilandia</option>
            <option value="TH"  
                >Tailandia</option>
            <option value="TW"  
                >Taiwán</option>
            <option value="TZ"  
                >Tanzania, República Unida de</option>
            <option value="TJ"  
                >Tayikistán</option>
            <option value="IO"  
                >Territorio Británico del Océano Índico</option>
            <option value="TF"  
                >Territorios Franceses del Sur</option>
            <option value="TL"  
                >Timor-Leste</option>
            <option value="TG"  
                >Togo</option>
            <option value="TK"  
                >Tokelau</option>
            <option value="TO"  
                >Tonga</option>
            <option value="TT"  
                >Trinidad y Tobago</option>
            <option value="TN"  
                >Túnez</option>
            <option value="TM"  
                >Turkmenistán</option>
            <option value="TR"  
                >Turquía</option>
            <option value="TV"  
                >Tuvalu</option>
            <option value="UA"  
                >Ucrania</option>
            <option value="UG"  
                >Uganda</option>
            <option value="UM"  
                >United States Minor Outlying Islands</option>
            <option value="UY"  
                >Uruguay</option>
            <option value="UZ"  
                >Uzbekistan</option>
            <option value="VU"  
                >Vanuatu</option>
            <option value="VE"  
                >Venezuela (República Bolivariana de)</option>
            <option value="VN"  
                >Vietnam</option>
            <option value="YE"  
                >Yemen</option>
            <option value="ZM"  
                >Zambia</option>
            <option value="ZW"  
                >Zimbawe</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_country" >
            
        </div>
    </div>
</div><div id="fgroup_id_buttonar" class="form-group row  fitem femptylabel  " data-groupname="buttonar">
    <div class="col-md-3 col-form-label d-flex pb-0 pr-md-0">
        
        <div class="form-label-addon d-flex align-items-center align-self-start">
            
        </div>
    </div>
    <div class="col-md-9 form-inline align-items-start felement" data-fieldtype="group">
        <fieldset class="w-100 m-0 p-0 border-0">
            <div class="d-flex flex-wrap align-items-center">
                
                <div class="form-group  fitem  " >
    <span data-fieldtype="submit">
        <input type="submit"
                class="btn
                        btn-primary
                        
                    
                    "
                name="submitbutton"
                id="id_submitbutton"
                value="Crear cuenta"
                 >
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_submitbutton" >
        
    </div>
</div>
                 
                <div class="form-group  fitem   btn-cancel" >
    <span data-fieldtype="submit">
        <input type="submit"
                class="btn
                        
                        btn-secondary
                    
                    "
                name="cancel"
                id="id_cancel"
                value="Cancelar"
                data-skip-validation="1" data-cancel="1" onclick="skipClientValidation = true; return true;" >
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_cancel" >
        
    </div>
</div>
            </div>
        </fieldset>
        <div class="form-control-feedback invalid-feedback" id="fgroup_id_error_buttonar" >
            
        </div>
    </div>
</div>
		<div class="fdescription required"><i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Campo obligatorio" role="img" aria-label="Campo obligatorio"></i> Requerido</div>
</form>
<script>var skipClientValidation = false;</script>
</div></div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>

<div class="d-none">
    <a class="mobilelink" href="https://download.moodle.org/mobile?version=2022112804.08&amp;lang=es&amp;iosappid=633359593&amp;androidappid=com.moodle.moodlemobile">Descargar la app para dispositivos móviles</a>
    <script>
//<![CDATA[
var require = {
    baseUrl : 'https://univirtual.uni.pe/lib/requirejs.php/1711504034/',
    // We only support AMD modules with an explicit define() statement.
    enforceDefine: true,
    skipDataMain: true,
    waitSeconds : 0,

    paths: {
        jquery: 'https://univirtual.uni.pe/lib/javascript.php/1711504034/lib/jquery/jquery-3.6.1.min',
        jqueryui: 'https://univirtual.uni.pe/lib/javascript.php/1711504034/lib/jquery/ui-1.13.2/jquery-ui.min',
        jqueryprivate: 'https://univirtual.uni.pe/lib/javascript.php/1711504034/lib/requirejs/jquery-private'
    },

    // Custom jquery config map.
    map: {
      // '*' means all modules will get 'jqueryprivate'
      // for their 'jquery' dependency.
      '*': { jquery: 'jqueryprivate' },
      // Stub module for 'process'. This is a workaround for a bug in MathJax (see MDL-60458).
      '*': { process: 'core/first' },

      // 'jquery-private' wants the real jQuery module
      // though. If this line was not here, there would
      // be an unresolvable cyclic dependency.
      jqueryprivate: { jquery: 'jquery' }
    }
};

//]]>
</script>
<script src="https://univirtual.uni.pe/lib/javascript.php/1711504034/lib/requirejs/require.min.js"></script>
<script>
//<![CDATA[
M.util.js_pending("core/first");
require(['core/first'], function() {
require(['core/prefetch'])
;
require(["media_videojs/loader"], function(loader) {
    loader.setUp('es');
});;

    M.util.js_pending('theme_boost/loader');
    require(['theme_boost/loader'], function() {
      M.util.js_complete('theme_boost/loader');
    });
;
M.util.js_pending('core_form/changechecker'); require(['core_form/changechecker'], function(amd) {amd.watchFormById("mform1_vq5rEzJkbYuhrg5"); M.util.js_complete('core_form/changechecker');});;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_username");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_passwordpolicyinfo");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_password");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_email");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_email2");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_firstname");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_lastname");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_city");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_country");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_submitbutton");
});
;

        require(['core_form/submit'], function(Submit) {
            Submit.init("id_submitbutton");
        });
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_cancel");
});
;

        require(['core_form/submit'], function(Submit) {
            Submit.init("id_cancel");
        });
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("fgroup_id_buttonar");
});
;

require(['jquery'], function($) {
    $('#fgroup_id_buttonar_label').css('cursor', 'default');
    $('#fgroup_id_buttonar_label').click(function() {
        $('#fgroup_id_buttonar')
            .find('button, a, input:not([type="hidden"]), select, textarea, [tabindex]')
            .filter(':not([disabled]):not([tabindex="0"]):not([tabindex="-1"])')
            .first().focus();
    });
});
;


require([
    "core_form/events",
    "jquery",
], function(
    FormEvents,
    $
) {

    function qf_errorHandler(element, _qfMsg, escapedName) {
        const event = FormEvents.notifyFieldValidationFailure(element, _qfMsg);
        if (event.defaultPrevented) {
            return _qfMsg == '';
        } else {
            // Legacy mforms.
            var div = element.parentNode;

            if ((div == undefined) || (element.name == undefined)) {
                // No checking can be done for undefined elements so let server handle it.
                return true;
            }

            if (_qfMsg != '') {
                var errorSpan = document.getElementById('id_error_' + escapedName);
                if (!errorSpan) {
                    errorSpan = document.createElement("span");
                    errorSpan.id = 'id_error_' + escapedName;
                    errorSpan.className = "error";
                    element.parentNode.insertBefore(errorSpan, element.parentNode.firstChild);
                    document.getElementById(errorSpan.id).setAttribute('TabIndex', '0');
                    document.getElementById(errorSpan.id).focus();
                }

                while (errorSpan.firstChild) {
                    errorSpan.removeChild(errorSpan.firstChild);
                }

                errorSpan.appendChild(document.createTextNode(_qfMsg.substring(3)));

                if (div.className.substr(div.className.length - 6, 6) != " error"
                        && div.className != "error") {
                    div.className += " error";
                    linebreak = document.createElement("br");
                    linebreak.className = "error";
                    linebreak.id = 'id_error_break_' + escapedName;
                    errorSpan.parentNode.insertBefore(linebreak, errorSpan.nextSibling);
                }

                return false;
            } else {
                var errorSpan = document.getElementById('id_error_' + escapedName);
                if (errorSpan) {
                    errorSpan.parentNode.removeChild(errorSpan);
                }
                var linebreak = document.getElementById('id_error_break_' + escapedName);
                if (linebreak) {
                    linebreak.parentNode.removeChild(linebreak);
                }

                if (div.className.substr(div.className.length - 6, 6) == " error") {
                    div.className = div.className.substr(0, div.className.length - 6);
                } else if (div.className == "error") {
                    div.className = "";
                }

                return true;
            } // End if.
        } // End if.
    } // End function.
    
    function validate_login_signup_form_username(element, escapedName) {
      if (undefined == element) {
         //required element was not found, then let form be submitted without client side validation
         return true;
      }
      var value = '';
      var errFlag = new Array();
      var _qfGroups = {};
      var _qfMsg = '';
      var frm = element.parentNode;
      if ((undefined != element.name) && (frm != undefined)) {
          while (frm && frm.nodeName.toUpperCase() != "FORM") {
            frm = frm.parentNode;
          }
          value = frm.elements['username'].value;
  if (value == '' && !errFlag['username']) {
    errFlag['username'] = true;
    _qfMsg = _qfMsg + '\n - Falta el nombre de usuario';
  }

          return qf_errorHandler(element, _qfMsg, escapedName);
      } else {
        //element name should be defined else error msg will not be displayed.
        return true;
      }
    }

    document.getElementById('id_username').addEventListener('blur', function(ev) {
        validate_login_signup_form_username(ev.target, 'username')
    });
    document.getElementById('id_username').addEventListener('change', function(ev) {
        validate_login_signup_form_username(ev.target, 'username')
    });

    function validate_login_signup_form_password(element, escapedName) {
      if (undefined == element) {
         //required element was not found, then let form be submitted without client side validation
         return true;
      }
      var value = '';
      var errFlag = new Array();
      var _qfGroups = {};
      var _qfMsg = '';
      var frm = element.parentNode;
      if ((undefined != element.name) && (frm != undefined)) {
          while (frm && frm.nodeName.toUpperCase() != "FORM") {
            frm = frm.parentNode;
          }
          value = frm.elements['password'].value;
  if (value == '' && !errFlag['password']) {
    errFlag['password'] = true;
    _qfMsg = _qfMsg + '\n - Falta la contraseña';
  }

          return qf_errorHandler(element, _qfMsg, escapedName);
      } else {
        //element name should be defined else error msg will not be displayed.
        return true;
      }
    }

    document.getElementById('id_password').addEventListener('blur', function(ev) {
        validate_login_signup_form_password(ev.target, 'password')
    });
    document.getElementById('id_password').addEventListener('change', function(ev) {
        validate_login_signup_form_password(ev.target, 'password')
    });

    function validate_login_signup_form_email(element, escapedName) {
      if (undefined == element) {
         //required element was not found, then let form be submitted without client side validation
         return true;
      }
      var value = '';
      var errFlag = new Array();
      var _qfGroups = {};
      var _qfMsg = '';
      var frm = element.parentNode;
      if ((undefined != element.name) && (frm != undefined)) {
          while (frm && frm.nodeName.toUpperCase() != "FORM") {
            frm = frm.parentNode;
          }
          value = frm.elements['email'].value;
  if (value == '' && !errFlag['email']) {
    errFlag['email'] = true;
    _qfMsg = _qfMsg + '\n - Falta la dirección de correo';
  }

          return qf_errorHandler(element, _qfMsg, escapedName);
      } else {
        //element name should be defined else error msg will not be displayed.
        return true;
      }
    }

    document.getElementById('id_email').addEventListener('blur', function(ev) {
        validate_login_signup_form_email(ev.target, 'email')
    });
    document.getElementById('id_email').addEventListener('change', function(ev) {
        validate_login_signup_form_email(ev.target, 'email')
    });

    function validate_login_signup_form_email2(element, escapedName) {
      if (undefined == element) {
         //required element was not found, then let form be submitted without client side validation
         return true;
      }
      var value = '';
      var errFlag = new Array();
      var _qfGroups = {};
      var _qfMsg = '';
      var frm = element.parentNode;
      if ((undefined != element.name) && (frm != undefined)) {
          while (frm && frm.nodeName.toUpperCase() != "FORM") {
            frm = frm.parentNode;
          }
          value = frm.elements['email2'].value;
  if (value == '' && !errFlag['email2']) {
    errFlag['email2'] = true;
    _qfMsg = _qfMsg + '\n - Falta la dirección de correo';
  }

          return qf_errorHandler(element, _qfMsg, escapedName);
      } else {
        //element name should be defined else error msg will not be displayed.
        return true;
      }
    }

    document.getElementById('id_email2').addEventListener('blur', function(ev) {
        validate_login_signup_form_email2(ev.target, 'email2')
    });
    document.getElementById('id_email2').addEventListener('change', function(ev) {
        validate_login_signup_form_email2(ev.target, 'email2')
    });

    function validate_login_signup_form_firstname(element, escapedName) {
      if (undefined == element) {
         //required element was not found, then let form be submitted without client side validation
         return true;
      }
      var value = '';
      var errFlag = new Array();
      var _qfGroups = {};
      var _qfMsg = '';
      var frm = element.parentNode;
      if ((undefined != element.name) && (frm != undefined)) {
          while (frm && frm.nodeName.toUpperCase() != "FORM") {
            frm = frm.parentNode;
          }
          value = frm.elements['firstname'].value;
  if (value == '' && !errFlag['firstname']) {
    errFlag['firstname'] = true;
    _qfMsg = _qfMsg + '\n - Falta el nombre dado';
  }

          return qf_errorHandler(element, _qfMsg, escapedName);
      } else {
        //element name should be defined else error msg will not be displayed.
        return true;
      }
    }

    document.getElementById('id_firstname').addEventListener('blur', function(ev) {
        validate_login_signup_form_firstname(ev.target, 'firstname')
    });
    document.getElementById('id_firstname').addEventListener('change', function(ev) {
        validate_login_signup_form_firstname(ev.target, 'firstname')
    });

    function validate_login_signup_form_lastname(element, escapedName) {
      if (undefined == element) {
         //required element was not found, then let form be submitted without client side validation
         return true;
      }
      var value = '';
      var errFlag = new Array();
      var _qfGroups = {};
      var _qfMsg = '';
      var frm = element.parentNode;
      if ((undefined != element.name) && (frm != undefined)) {
          while (frm && frm.nodeName.toUpperCase() != "FORM") {
            frm = frm.parentNode;
          }
          value = frm.elements['lastname'].value;
  if (value == '' && !errFlag['lastname']) {
    errFlag['lastname'] = true;
    _qfMsg = _qfMsg + '\n - Falta(n) apellido(s)';
  }

          return qf_errorHandler(element, _qfMsg, escapedName);
      } else {
        //element name should be defined else error msg will not be displayed.
        return true;
      }
    }

    document.getElementById('id_lastname').addEventListener('blur', function(ev) {
        validate_login_signup_form_lastname(ev.target, 'lastname')
    });
    document.getElementById('id_lastname').addEventListener('change', function(ev) {
        validate_login_signup_form_lastname(ev.target, 'lastname')
    });


    function validate_login_signup_form() {
      if (skipClientValidation) {
         return true;
      }
      var ret = true;

      var frm = document.getElementById('mform1_vq5rEzJkbYuhrg5')
      var first_focus = false;
    
      ret = validate_login_signup_form_username(frm.elements['username'], 'username') && ret;
      if (!ret && !first_focus) {
        first_focus = true;
        const element = document.getElementById("id_error_username");
        if (element) {
          FormEvents.notifyFormError(element);
          element.focus();
        }
      }

      ret = validate_login_signup_form_password(frm.elements['password'], 'password') && ret;
      if (!ret && !first_focus) {
        first_focus = true;
        const element = document.getElementById("id_error_password");
        if (element) {
          FormEvents.notifyFormError(element);
          element.focus();
        }
      }

      ret = validate_login_signup_form_email(frm.elements['email'], 'email') && ret;
      if (!ret && !first_focus) {
        first_focus = true;
        const element = document.getElementById("id_error_email");
        if (element) {
          FormEvents.notifyFormError(element);
          element.focus();
        }
      }

      ret = validate_login_signup_form_email2(frm.elements['email2'], 'email2') && ret;
      if (!ret && !first_focus) {
        first_focus = true;
        const element = document.getElementById("id_error_email2");
        if (element) {
          FormEvents.notifyFormError(element);
          element.focus();
        }
      }

      ret = validate_login_signup_form_firstname(frm.elements['firstname'], 'firstname') && ret;
      if (!ret && !first_focus) {
        first_focus = true;
        const element = document.getElementById("id_error_firstname");
        if (element) {
          FormEvents.notifyFormError(element);
          element.focus();
        }
      }

      ret = validate_login_signup_form_lastname(frm.elements['lastname'], 'lastname') && ret;
      if (!ret && !first_focus) {
        first_focus = true;
        const element = document.getElementById("id_error_lastname");
        if (element) {
          FormEvents.notifyFormError(element);
          element.focus();
        }
      }
;
      return ret;
    }

    var form = document.getElementById('mform1_vq5rEzJkbYuhrg5').closest('form');
    form.addEventListener(FormEvents.eventTypes.formSubmittedByJavascript, () => {
        try {
            var myValidator = validate_login_signup_form;
        } catch(e) {
            return;
        }
        if (myValidator) {
            myValidator();
        }
    });

    document.getElementById('mform1_vq5rEzJkbYuhrg5').addEventListener('submit', function(ev) {
        try {
            var myValidator = validate_login_signup_form;
        } catch(e) {
            return true;
        }
        if (typeof window.tinyMCE !== 'undefined') {
            window.tinyMCE.triggerSave();
        }
        if (!myValidator()) {
            ev.preventDefault();
        }
    });

});
;
M.util.js_pending('core/notification'); require(['core/notification'], function(amd) {amd.init(1, []); M.util.js_complete('core/notification');});;
M.util.js_pending('core/log'); require(['core/log'], function(amd) {amd.setConfig({"level":"warn"}); M.util.js_complete('core/log');});;
M.util.js_pending('core/page_global'); require(['core/page_global'], function(amd) {amd.init(); M.util.js_complete('core/page_global');});;
M.util.js_pending('core/utility'); require(['core/utility'], function(amd) {M.util.js_complete('core/utility');});
    M.util.js_complete("core/first");
});
//]]>
</script>
<script>
//<![CDATA[
M.str = {"moodle":{"lastmodified":"\u00daltima modificaci\u00f3n","name":"Nombre","error":"Error","info":"Informaci\u00f3n","yes":"S\u00ed","no":"No","cancel":"Cancelar","confirm":"Confirmar","areyousure":"\u00bfEst\u00e1 seguro?","closebuttontitle":"Cerrar","unknownerror":"Error desconocido","file":"Archivo","url":"URL","collapseall":"Colapsar todo","expandall":"Expandir todo"},"repository":{"type":"Tipo","size":"Tama\u00f1o","invalidjson":"Cadena JSON no v\u00e1lida","nofilesattached":"No se han adjuntado archivos","filepicker":"Selector de archivos","logout":"Salir","nofilesavailable":"No hay archivos disponibles","norepositoriesavailable":"Lo sentimos, ninguno de sus repositorios actuales puede devolver archivos en el formato solicitado.","fileexistsdialogheader":"El archivo existe","fileexistsdialog_editor":"Un archivo con ese nombre ha sido anexado al texto que Usted est\u00e1 editando","fileexistsdialog_filemanager":"Ya ha sido anexado un archivo con ese nombre","renameto":"Cambiar el nombre a \"{$a}\"","referencesexist":"Existen {$a} enlaces a este archivo","select":"Seleccionar"},"admin":{"confirmdeletecomments":"Est\u00e1 a punto de eliminar comentarios, \u00bfest\u00e1 seguro?","confirmation":"Confirmaci\u00f3n"},"debug":{"debuginfo":"Informaci\u00f3n de depuraci\u00f3n","line":"L\u00ednea","stacktrace":"Trazado de la pila (stack)"},"langconfig":{"labelsep":":"}};
//]]>
</script>
<script>
//<![CDATA[
(function() {Y.use("moodle-filter_mathjaxloader-loader",function() {M.filter_mathjaxloader.configure({"mathjaxconfig":"\nMathJax.Hub.Config({\n    config: [\"Accessible.js\", \"Safe.js\"],\n    errorSettings: { message: [\"!\"] },\n    skipStartupTypeset: true,\n    messageStyle: \"none\"\n});\n","lang":"es"});
});
M.util.help_popups.setup(Y);
 M.util.js_pending('random669049e08d51c2'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random669049e08d51c2'); });
})();
//]]>
</script>

</div>
</body>
</html>